package com.example.app_02042024;

import android.os.Parcel;
import android.os.Parcelable;

public class Entreprise implements Parcelable {
    private String nom;
    private String adresse;
    private String contact;

    public Entreprise(String nom, String adresse, String contact) {
        this.nom = nom;
        this.adresse = adresse;
        this.contact = contact;
    }

    protected Entreprise(Parcel in) {
        nom = in.readString();
        adresse = in.readString();
        contact = in.readString();
    }

    public static final Creator<Entreprise> CREATOR = new Creator<Entreprise>() {
        @Override
        public Entreprise createFromParcel(Parcel in) {
            return new Entreprise(in);
        }

        @Override
        public Entreprise[] newArray(int size) {
            return new Entreprise[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(nom);
        dest.writeString(adresse);
        dest.writeString(contact);
    }

    public String getNom() {
        return nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public String getContact() {
        return contact;
    }

    @Override
    public String toString() {
        return nom + " - " + adresse + " - " + contact;
    }
}

