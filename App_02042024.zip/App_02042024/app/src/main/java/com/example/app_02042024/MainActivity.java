package com.example.app_02042024;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ArrayList<Entreprise> entreprises;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View mainLayout = findViewById(R.id.main);

        // Gérer les insets pour les composants UI
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout, (v, insets) -> {
            Insets systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBarsInsets.left, systemBarsInsets.top, systemBarsInsets.right, systemBarsInsets.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        // Initialiser les entreprises
        entreprises = new ArrayList<>();
        if (!chargerListe()) {
            initEntreprises();
        }

        Button btval = findViewById(R.id.validate_button);
        btval.setOnClickListener(this);

        Button btann = findViewById(R.id.cancel_button);
        btann.setOnClickListener(this);
    }

    private void initEntreprises() {
        entreprises.add(new Entreprise("Entreprise A", "Adresse A", "Contact A"));
        entreprises.add(new Entreprise("Entreprise B", "Adresse B", "Contact B"));
        entreprises.add(new Entreprise("Entreprise C", "Adresse C", "Contact C"));
        sauvegarderListe();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i("App02042024", "Application stopee");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("App02042024", "Application redemarree");
    }

    @Override
    public void onClick(View v) {
        EditText loginEditText = findViewById(R.id.login_edittext);
        EditText passwordEditText = findViewById(R.id.password_edittext);
        TextView resultTextView = findViewById(R.id.result_textview);

        if (v.getId() == R.id.validate_button) {
            String rslt = loginEditText.getText().toString();
            if (!rslt.isEmpty()) {
                resultTextView.setText("Bonjour " + rslt);

                // Démarrer ContactListActivity avec la liste d'entreprises
                Intent intent = new Intent(MainActivity.this, ContactListActivity.class);
                intent.putParcelableArrayListExtra("entreprises", entreprises);
                startActivity(intent);
            }
        }
        if (v.getId() == R.id.cancel_button) {
            loginEditText.setText("");
            passwordEditText.setText("");
            resultTextView.setText("");
        }
    }

    public boolean chargerListe() {
        boolean r = true;
        entreprises.clear();
        try {
            FileInputStream fin = openFileInput("entreprises.csv");
            InputStreamReader in = new InputStreamReader(fin);
            BufferedReader buffer = new BufferedReader(in);
            String ligne = buffer.readLine();
            while (ligne != null) {
                String[] parts = ligne.split(";");
                if (parts.length == 3) {
                    entreprises.add(new Entreprise(parts[0], parts[1], parts[2]));
                }
                ligne = buffer.readLine();
            }
            in.close();
        } catch (Exception e) {
            r = false;
            e.printStackTrace();
        }
        return r;
    }

    public boolean sauvegarderListe() {
        boolean r = true;
        try {
            FileOutputStream fout = openFileOutput("entreprises.csv", Context.MODE_PRIVATE);
            OutputStreamWriter out = new OutputStreamWriter(fout);
            BufferedWriter buffer = new BufferedWriter(out);
            for (Entreprise entreprise : entreprises) {
                buffer.write(entreprise.getNom() + ";" + entreprise.getAdresse() + ";" + entreprise.getContact() + "\n");
            }
            buffer.close();
        } catch (Exception e) {
            r = false;
            e.printStackTrace();
        }
        return r;
    }
}
