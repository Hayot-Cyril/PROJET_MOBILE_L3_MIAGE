package com.example.app_02042024;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button changePasswordButton = findViewById(R.id.change_password_button);
        Button logoutButton = findViewById(R.id.logout_button);
        Button deleteAccountButton = findViewById(R.id.delete_account_button);

        changePasswordButton.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, ChangePasswordActivity.class);
            startActivity(intent);
        });

        logoutButton.setOnClickListener(v -> {
            // Logique pour déconnexion
        });

        deleteAccountButton.setOnClickListener(v -> {
            // Logique pour suppression du compte
        });
    }

    private void confirmDeleteAccount() {
        // Afficher un dialogue de confirmation avant la suppression du compte
    }

}