package com.example.app_02042024;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class AjoutEntrepriseActivity extends AppCompatActivity {

    private EditText nomEditText;
    private EditText adresseEditText;
    private EditText contactEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_entreprise);

        nomEditText = findViewById(R.id.nom_edittext);
        adresseEditText = findViewById(R.id.adresse_edittext);
        contactEditText = findViewById(R.id.contact_edittext);
        saveButton = findViewById(R.id.save_button);

        // Check if an existing company is passed
        Intent intent = getIntent();
        if (intent.hasExtra("entreprise")) {
            Entreprise entreprise = intent.getParcelableExtra("entreprise");
            if (entreprise != null) {
                nomEditText.setText(entreprise.getNom());
                adresseEditText.setText(entreprise.getAdresse());
                contactEditText.setText(entreprise.getContact());
            }
        }

        saveButton.setOnClickListener(v -> {
            String nom = nomEditText.getText().toString();
            String adresse = adresseEditText.getText().toString();
            String contact = contactEditText.getText().toString();

            Entreprise newEntreprise = new Entreprise(nom, adresse, contact);

            Intent resultIntent = new Intent();
            resultIntent.putExtra("new_entreprise", newEntreprise);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}
