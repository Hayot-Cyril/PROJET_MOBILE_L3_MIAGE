package com.example.app_02042024;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class ContactListActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_ADD = 1;
    private ArrayList<Entreprise> entreprises;
    private ArrayAdapter<Entreprise> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        entreprises = getIntent().getParcelableArrayListExtra("entreprises");

        ListView listView = findViewById(R.id.contact_list_view);
        Button addButton = findViewById(R.id.add_button);
        Button menuButton = findViewById(R.id.menuButton);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, entreprises);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            Entreprise selectedEntreprise = entreprises.get(position);
            Intent intent = new Intent(ContactListActivity.this, AjoutEntrepriseActivity.class);
            intent.putExtra("entreprise", selectedEntreprise);
            startActivity(intent);
        });

        addButton.setOnClickListener(v -> {
            Intent intent = new Intent(ContactListActivity.this, AjoutEntrepriseActivity.class);
            startActivityForResult(intent, REQUEST_CODE_ADD);
        });

        menuButton.setOnClickListener(v -> {
            Intent intent = new Intent(ContactListActivity.this, MenuActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_ADD && resultCode == RESULT_OK) {
            Entreprise newEntreprise = data.getParcelableExtra("new_entreprise");
            entreprises.add(newEntreprise);
            adapter.notifyDataSetChanged();

            // Sauvegarder la liste mise à jour
            sauvegarderListe();
        }
    }

    private void sauvegarderListe() {
        try {
            FileOutputStream fout = openFileOutput("entreprises.csv", Context.MODE_PRIVATE);
            OutputStreamWriter out = new OutputStreamWriter(fout);
            BufferedWriter buffer = new BufferedWriter(out);
            for (Entreprise entreprise : entreprises) {
                buffer.write(entreprise.getNom() + ";" + entreprise.getAdresse() + ";" + entreprise.getContact() + "\n");
            }
            buffer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
