// ChangePasswordActivity.java
package com.example.app_02042024;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ChangePasswordActivity extends AppCompatActivity {

    private EditText oldPasswordEditText;
    private EditText newPasswordEditText;
    private String username = "cyril";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        oldPasswordEditText = findViewById(R.id.old_password_edittext);
        newPasswordEditText = findViewById(R.id.new_password_edittext);
        Button changePasswordButton = findViewById(R.id.change_password_button);

        changePasswordButton.setOnClickListener(v -> {
            String oldPassword = oldPasswordEditText.getText().toString();
            String newPassword = newPasswordEditText.getText().toString();

            if (changePassword(username, oldPassword, newPassword)) {
                Toast.makeText(this, "Mot de passe changé avec succès", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Échec du changement de mot de passe", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean changePassword(String username, String oldPassword, String newPassword) {
        String filePath = "C:\\Users\\kileu\\AndroidStudioProjects\\App_02042024\\app\\src\\main\\assets\\users.csv";
        List<String[]> users = new ArrayList<>();

        // Lire le fichier CSV
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userDetails = line.split(";");
                users.add(userDetails);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        // Vérifier et mettre à jour le mot de passe
        boolean passwordChanged = false;
        for (String[] user : users) {
            if (user[0].equals(username) && user[1].equals(oldPassword)) {
                user[1] = newPassword;
                passwordChanged = true;
                break;
            }
        }

        if (!passwordChanged) {
            return false;
        }

        // Écrire les changements dans le fichier CSV
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (String[] user : users) {
                bw.write(user[0] + ";" + user[1]);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }
}
